-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 25 May 2022, 03:02:44
-- Sunucu sürümü: 10.4.22-MariaDB
-- PHP Sürümü: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sinema`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `filmler`
--

CREATE TABLE `filmler` (
  `id` int(25) NOT NULL,
  `Film Adı` varchar(25) NOT NULL,
  `Salon` int(11) NOT NULL,
  `Saat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `filmler`
--

INSERT INTO `filmler` (`id`, `Film Adı`, `Salon`, `Saat`) VALUES
(1, 'Yıldızlararası', 1, '2022-05-26 11:30:00'),
(2, 'Zindan Adası', 2, '2022-05-01 09:35:00'),
(3, 'Başlangıç', 1, '2022-05-27 13:00:00'),
(4, 'Esaretin Bedeli', 2, '2022-05-24 13:00:00'),
(5, 'Titanik', 3, '2022-05-24 17:30:00'),
(6, 'Shrek', 2, '2022-05-24 08:45:00'),
(7, 'Kung Fu Panda', 2, '2022-05-31 17:15:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `müşteriler`
--

CREATE TABLE `müşteriler` (
  `id` int(25) NOT NULL,
  `Müşteri Adı` varchar(25) NOT NULL,
  `Film` varchar(25) NOT NULL,
  `Koltuk No` varchar(25) NOT NULL,
  `Salon` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `müşteriler`
--

INSERT INTO `müşteriler` (`id`, `Müşteri Adı`, `Film`, `Koltuk No`, `Salon`) VALUES
(1, 'Serdar Oyar', 'Esaretin Bedeli', 'A1', 2),
(2, 'Serdar Oyar', 'Yıldızlararası', 'B2', 1),
(3, 'Helin Oyar', 'Shrek', 'A2', 2),
(4, 'Sıdıka Taşralı', 'Shrek', 'A3', 2),
(5, 'Seher Oyar', 'Kung Fu Panda', 'B3', 2);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `salon`
--

CREATE TABLE `salon` (
  `id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `salon`
--

INSERT INTO `salon` (`id`) VALUES
(1),
(2),
(3);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `filmler`
--
ALTER TABLE `filmler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Tablo için indeksler `müşteriler`
--
ALTER TABLE `müşteriler`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_salon` (`Salon`);

--
-- Tablo için indeksler `salon`
--
ALTER TABLE `salon`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `filmler`
--
ALTER TABLE `filmler`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Tablo için AUTO_INCREMENT değeri `müşteriler`
--
ALTER TABLE `müşteriler`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Tablo için AUTO_INCREMENT değeri `salon`
--
ALTER TABLE `salon`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `müşteriler`
--
ALTER TABLE `müşteriler`
  ADD CONSTRAINT `fk_salon` FOREIGN KEY (`Salon`) REFERENCES `salon` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
